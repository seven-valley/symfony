<?php

namespace App\Controller;

use App\Entity\Personne;
use App\form\PersonneType;
use App\Repository\PersonneRepository;
use Doctrine\ORM\EntityManagerInterface; 
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class AdminController extends AbstractController
{
    /**
     * @Route("/admin", name="admin")
     */
    public function home(): Response
    {
        return $this->render('admin/home.html.twig');
    }
    /**
     * @Route("/admin/personnes", name="admin_personnes")
     */
    public function personnes(
        EntityManagerInterface $em,
        PersonneRepository $repo,
        Request $request): Response
    {
        
        $personne = new Personne();//je créer un bo
        // on associe le bo au formulaire
        $form = $this->createForm(PersonneType::class, $personne);
        // traiter le formulaire
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()){
            $em->persist($personne);
            $em->flush();
            return $this->redirectToRoute('admin_personnes'); 
        }
        $personnes = $repo->findAll();

        return $this->render('admin/personnes.html.twig',[
            'personnes' => $personnes,
            'personneForm' => $form->createView()
        ]);
    }
    /**
     * @Route("/admin/delete-personne/{id}", name="delete_personne")
     */
    public function delete_personne(EntityManagerInterface $em, Personne $personne): Response
    {
       $em->remove($personne);
       $em->flush();
       return $this->redirectToRoute('admin_personnes'); 
    }
        /**
     * @Route("/admin/modifier-personne/{id}", name="modifier_personne")
     */
    public function modifier_personne(EntityManagerInterface $em, Personne $personne): Response
    {
       
       return $this->redirectToRoute('admin_personnes'); 
    }

}
